# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution. 

## Credential Values

- Android keystore password: 718cbf3191234d1d8c9d3c45d551548a
- Android key alias: QGthcmFuYWdnYXJ3YWx3aGpyc3R1ZGVudC9UUkFDS0VSSVNT
- Android key password: d2bce913ca494e2cad3b2008e8bac2b1
      